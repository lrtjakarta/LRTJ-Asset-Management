#!/bin/sh
set -e

cd /var/www/html

# Create .env if missing
if [ ! -f .env ] && [ -f .env.example ]; then
  cp .env.example .env
fi

# Ensure writable dirs
mkdir -p storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache || true
chmod -R ug+rwx storage bootstrap/cache || true

# Install composer deps if vendor missing
if [ ! -d vendor ]; then
  composer install --no-interaction --prefer-dist
fi

# Generate app key if empty
if php -r 'exit((int) (empty(env("APP_KEY"))));' >/dev/null 2>&1; then
  php artisan key:generate --force || true
fi

exec "$@"
