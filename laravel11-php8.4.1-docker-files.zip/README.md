# Laravel 11 + PHP 8.4.1 Docker (Nginx + PHP-FPM + Postgres + Redis)

## Quick start

From your Laravel project root (same level as `composer.json`):

```bash
docker compose up -d --build
docker compose exec app php artisan migrate
```

Open: http://localhost:8080

## Suggested `.env` values

```env
APP_URL=http://localhost:8080

DB_CONNECTION=pgsql
DB_HOST=db
DB_PORT=5432
DB_DATABASE=laravel
DB_USERNAME=laravel
DB_PASSWORD=laravel

REDIS_CLIENT=predis
REDIS_HOST=redis
REDIS_PORT=6379
```

## Files

- `Dockerfile`
- `docker-compose.yml`
- `docker/nginx/default.conf`
- `docker/php/local.ini`
- `docker/entrypoint.sh`
